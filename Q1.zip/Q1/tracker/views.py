from email import message
from pyexpat.errors import messages
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login,authenticate, logout
from tracker.forms import WorkForm, WorkerForm, SignupForm
from . import models
# Create your views here.

def home(request):
    return render(request, "index.html")

#user authentication and registration
def login_users(request):
    if request.method=="POST":
        username=request.POST['username']
        passw=request.POST['passw']
        user=authenticate(request, username=username, password=passw)
        if user is not None:
            login(request, user)

            return redirect('home')

        else:
            return redirect("login")
    else:
        return render(request, "authentic/login.html")

def logout_users(request):
    logout(request)
    return redirect("home")

def signup_users(request):
    if request.method=="POST":
        data=SignupForm(request.POST)
        if data.is_valid():
            new_user=data.save()

            login(request, new_user)
            return redirect('home')
    else:
        data=SignupForm()

    return render(request, "authentic/signup.html", {"form":data})


def work(request):
    try:
        data=models.WorkTracker.objects.all()
        context={"data":data}
    except Exception as e:
        context={"data":"No Data"}  
    return render(request, "work.html", context)

def workadd(request):
    form=WorkForm()
    if request.method == 'POST':
        myData=WorkForm(request.POST)
        if myData.is_valid():
            myData.save()
            return redirect('home')
    context={"data":form}
    messages.success(request,'Row added successfully.')
    return render(request,'workadd.html',context)

def workdelete(request, id):
    data=models.WorkTracker.objects.get(id=id)
    data.delete()
    messages.success(request,'Row deleted successfully.')
    return redirect('work')

def workupdate(request, id):
    data=models.WorkTracker.objects.get(id=id)
    updateform=WorkForm(request.POST or None,instance=data)
    if updateform.is_valid():
        updateform.save()
        
        return redirect('work')
    context={"data":updateform}
    messages.success(request,'Row updated successfully.')
    return render(request,'workupdate.html',context)

def worker(request):
    try:
        data=models.WorkerTracker.objects.all()
        context={"data":data}
    except Exception as e:
        context={"data":"No Data"}
    return render(request, "worker.html", context)

def workeradd(request):
    form=WorkerForm()
    if request.method == 'POST':
        myData=WorkerForm(request.POST)
        if myData.is_valid():
            myData.save()
            return redirect('worker')
    context={"data":form}
    messages.success(request,'Row added successfully.')
    return render(request,'workeradd.html',context)

def workerupdate(request, id):
    data=models.WorkerTracker.objects.get(id=id)
    updateform=WorkerForm(request.POST or None,instance=data)
    if updateform.is_valid():
        updateform.save()
        
        return redirect('worker')
    context={"data":updateform}
    messages.success(request,'Row updated successfully.')
    return render(request,'workerupdate.html',context)

def workerdelete(request, id):
    data=models.WorkerTracker.objects.get(id=id)
    data.delete()
    messages.success(request,'Row deleted successfully.')
    return redirect('worker')

