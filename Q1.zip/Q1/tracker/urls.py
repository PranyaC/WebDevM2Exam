from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    
    path('work/', views.work, name="work"),
    path('workadd/', views.workadd, name="workadd"),
    path('workdelete/<str:id>', views.workdelete, name="workdelete"),
    path('workupdate/<str:id>', views.workupdate, name="workupdate"),

    path('worker/', views.worker, name="worker"),
    path('workeradd/', views.workeradd, name="workeradd"),
    path('workerupdate/<str:id>', views.workerupdate, name="workerupdate"),
    path('workerdelete/<str:id>', views.workerdelete, name="workerdelete"),
    
    path('login/', views.login_users, name="login"),
    path('logout/', views.logout_users, name="logout"),
    path('signup/', views.signup_users, name="signup"),
    #path('login/', include("django.contrib.auth.urls")
]