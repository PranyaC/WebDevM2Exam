from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import WorkTracker, WorkerTracker


@receiver(post_save, sender=WorkTracker)
def autoCreateWorker(sender, instance, created, **kwargs):
    if created:
        print('signal test')
        
        WorkerTracker.objects.create(
            data = instance
            name = data.name
            date = data.date
            
        )
        

@receiver(post_delete, sender=WorkTracker)
def autoDelWorker(sender, instance, **kwargs):
    name=instance.name
    data=WorkerTracker.objects.get(name=name)
    data.delete()
    # print("Post Delete Signal called")