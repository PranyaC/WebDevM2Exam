from datetime import date
from random import choices
from django.db import models

# Create your models here.

class WorkTracker(models.Model):
    name=models.CharField(max_length=100, null=True)
    date=models.CharField(max_length=10)
    work_done = models.CharField(max_length=100)
    work_description = models.CharField(max_length=200)
    created_at=models.DateTimeField(auto_now=True)
    updated_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name + " " + self.date + " " + self.work_done
    class Meta:
        verbose_name_plural = "WorkTracker"



class WorkerTracker(models.Model):
    name=models.CharField(max_length=100, null=True)
    date=models.CharField(max_length=10)

    def __str__(self):
        return self.name +' '+self.date
    class Meta:
        verbose_name_plural = "WorkerTracker"

